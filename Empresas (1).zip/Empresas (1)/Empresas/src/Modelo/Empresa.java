package Modelo;

/**
 * Clase que representa una empresa con sus respectivos datos de identificación,
 * contacto y localización.
 */
public class Empresa {
    int ID_empresas;
    String nit, nombre_empresa, direccion, area, contacto, email, departamento, ciudad;

    /**
     * Constructor para crear una instancia de la clase Modelo.Empresa.
     *
     * @param ID_empresas   Identificador único de la empresa.
     * @param nit           Número de Identificación Tributaria de la empresa.
     * @param nombre_empresa Nombre oficial de la empresa.
     * @param direccion     Dirección física de la empresa.
     * @param area          Área o sector al que pertenece la empresa.
     * @param contacto      Persona o número de contacto de la empresa.
     * @param email         Correo electrónico de la empresa.
     * @param departamento  Departamento donde se ubica la empresa.
     * @param ciudad        Ciudad donde se ubica la empresa.
     */
    public Empresa(int ID_empresas, String nit, String nombre_empresa, String direccion, String area, String contacto, String email, String departamento, String ciudad) {
        this.ID_empresas = ID_empresas;
        this.nit = nit;
        this.nombre_empresa = nombre_empresa;
        this.direccion = direccion;
        this.area = area;
        this.contacto = contacto;
        this.email = email;
        this.departamento = departamento;
        this.ciudad = ciudad;
    }

    /**
     * @return el ID único de la empresa.
     */
    public int getID_empresas() {
        return ID_empresas;
    }

    /**
     * Establece el ID único de la empresa.
     *
     * @param ID_empresas nuevo ID de la empresa.
     */
    public void setID_empresas(int ID_empresas) {
        this.ID_empresas = ID_empresas;
    }

    /**
     * @return el NIT de la empresa.
     */
    public String getNit() {
        return nit;
    }

    /**
     * Establece el NIT de la empresa.
     *
     * @param nit nuevo NIT.
     */
    public void setNit(String nit) {
        this.nit = nit;
    }

    /**
     * @return el nombre de la empresa.
     */
    public String getNombre_empresa() {
        return nombre_empresa;
    }

    /**
     * Establece el nombre de la empresa.
     *
     * @param nombre_empresa nuevo nombre de la empresa.
     */
    public void setNombre_empresa(String nombre_empresa) {
        this.nombre_empresa = nombre_empresa;
    }

    /**
     * @return la dirección de la empresa.
     */
    public String getDireccion() {
        return direccion;
    }

    /**
     * Establece la dirección de la empresa.
     *
     * @param direccion nueva dirección.
     */
    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    /**
     * @return el área o sector de la empresa.
     */
    public String getArea() {
        return area;
    }

    /**
     * Establece el área o sector de la empresa.
     *
     * @param area nuevo valor para el área.
     */
    public void setArea(String area) {
        this.area = area;
    }

    /**
     * @return el contacto de la empresa.
     */
    public String getContacto() {
        return contacto;
    }

    /**
     * Establece el contacto de la empresa.
     *
     * @param contacto nuevo contacto.
     */
    public void setContacto(String contacto) {
        this.contacto = contacto;
    }

    /**
     * @return el correo electrónico de la empresa.
     */
    public String getEmail() {
        return email;
    }

    /**
     * Establece el correo electrónico de la empresa.
     *
     * @param email nuevo correo electrónico.
     */
    public void setEmail(String email) {
        this.email = email;
    }

    /**
     * @return el departamento de la empresa.
     */
    public String getDepartamento() {
        return departamento;
    }

    /**
     * Establece el departamento donde se encuentra la empresa.
     *
     * @param departamento nuevo departamento.
     */
    public void setDepartamento(String departamento) {
        this.departamento = departamento;
    }

    /**
     * @return la ciudad donde se encuentra la empresa.
     */
    public String getCiudad() {
        return ciudad;
    }

    /**
     * Establece la ciudad donde se encuentra la empresa.
     *
     * @param ciudad nueva ciudad.
     */
    public void setCiudad(String ciudad) {
        this.ciudad = ciudad;
    }
}
